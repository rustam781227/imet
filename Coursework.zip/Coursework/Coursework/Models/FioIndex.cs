﻿using System;
using System.Collections.Generic;

namespace Coursework.Models
{
    public partial class FioIndex
    {
        public string? SFio { get; set; }
    }
}
