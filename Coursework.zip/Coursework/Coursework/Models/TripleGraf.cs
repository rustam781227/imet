﻿using System;
using System.Collections.Generic;

namespace Coursework.Models
{
    public partial class TripleGraf
    {
        public decimal NCount { get; set; }
        public string? SEl1 { get; set; }
        public string? SEl2 { get; set; }
        public string? SEl3 { get; set; }
        public string? STitle { get; set; }
        public byte[]? LImg { get; set; }
        public string? SCompoundName { get; set; }
    }
}
