﻿using System;
using System.Collections.Generic;

namespace Coursework.Models
{
    public partial class Page
    {
        public string? SPageFilename { get; set; }
    }
}
