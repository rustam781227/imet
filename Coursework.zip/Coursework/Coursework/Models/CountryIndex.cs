﻿using System;
using System.Collections.Generic;

namespace Coursework.Models
{
    public partial class CountryIndex
    {
        public string? SCountry { get; set; }
    }
}
