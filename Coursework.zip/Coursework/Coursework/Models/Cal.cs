﻿using System;
using System.Collections.Generic;

namespace Coursework.Models
{
    public partial class Cal
    {
        public decimal NNum { get; set; }
        public string SEl { get; set; } = null!;
        public string? LHtml { get; set; }
    }
}
