﻿using System;
using System.Collections.Generic;

namespace Coursework.Models
{
    public partial class Compound
    {
        public string SCompoundName { get; set; } = null!;
        public string? SElem1 { get; set; }
        public string? SElem2 { get; set; }
        public string? SElem3 { get; set; }
        public decimal? NCompoundid { get; set; }
        public decimal? NCompoundDimension { get; set; }
    }
}
