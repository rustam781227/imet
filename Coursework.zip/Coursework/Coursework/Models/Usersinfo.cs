﻿using System;
using System.Collections.Generic;

namespace Coursework.Models
{
    public partial class Usersinfo
    {
        public int Userid { get; set; }
        public decimal Accessmode { get; set; }
        public string Login { get; set; } = null!;
        public string Password { get; set; } = null!;
        public string Comments { get; set; } = null!;
        public decimal Updatestatus { get; set; }
    }
}
