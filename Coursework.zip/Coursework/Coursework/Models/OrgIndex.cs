﻿using System;
using System.Collections.Generic;

namespace Coursework.Models
{
    public partial class OrgIndex
    {
        public string? SOrg { get; set; }
    }
}
