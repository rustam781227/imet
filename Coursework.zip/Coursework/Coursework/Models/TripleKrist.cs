﻿using System;
using System.Collections.Generic;

namespace Coursework.Models
{
    public partial class TripleKrist
    {
        public decimal NCount { get; set; }
        public string? SEl1 { get; set; }
        public string? SEl2 { get; set; }
        public string? SEl3 { get; set; }
        public decimal? NNom { get; set; }
        public string? SFaza { get; set; }
        public string? STypestr { get; set; }
        public string? SPirson { get; set; }
        public string? SSpgr { get; set; }
        public double? NA { get; set; }
        public double? NPogr1 { get; set; }
        public double? NB { get; set; }
        public double? NPogr2 { get; set; }
        public double? NC { get; set; }
        public double? NPogr3 { get; set; }
        public double? NAlpha { get; set; }
        public double? NPogr4 { get; set; }
        public double? NBeta { get; set; }
        public double? NPogr5 { get; set; }
        public double? NGamma { get; set; }
        public double? NPogr6 { get; set; }
        public string? STitle { get; set; }
        public string? SCompoundName { get; set; }

        public virtual Literat? NNomNavigation { get; set; }
    }
}
