﻿using System;
using System.Collections.Generic;

namespace Coursework.Models
{
    public partial class Property
    {
        public Property()
        {
            Dbcontents = new HashSet<Dbcontent>();
        }

        public decimal Nomprop { get; set; }
        public decimal Updatestatus { get; set; }
        public string? Nazvprop { get; set; }
        public string? Html { get; set; }

        public virtual ICollection<Dbcontent> Dbcontents { get; set; }
    }
}
