﻿using System;
using System.Collections.Generic;

namespace Coursework.Models
{
    public partial class DoubleUrov
    {
        public string? SUrov { get; set; }
        public decimal NUrov { get; set; }
    }
}
