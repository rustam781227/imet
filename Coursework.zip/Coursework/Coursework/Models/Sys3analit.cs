﻿using System;
using System.Collections.Generic;

namespace Coursework.Models
{
    public partial class Sys3analit
    {
        public string SEl1 { get; set; } = null!;
        public string SEl2 { get; set; } = null!;
        public string SEl3 { get; set; } = null!;
        public string SEl { get; set; } = null!;
        public string LHtml { get; set; } = null!;
    }
}
