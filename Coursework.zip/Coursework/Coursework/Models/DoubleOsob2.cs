﻿using System;
using System.Collections.Generic;

namespace Coursework.Models
{
    public partial class DoubleOsob2
    {
        public decimal NCount { get; set; }
        public string? SEl1 { get; set; }
        public string? SEl2 { get; set; }
        public string? SReak { get; set; }
        public decimal? NNom { get; set; }
        public string? SFaza { get; set; }
        public double? NX { get; set; }
        public double? NPogr { get; set; }

        public virtual Literat? NNomNavigation { get; set; }
    }
}
