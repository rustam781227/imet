﻿using System;
using System.Collections.Generic;

namespace Coursework.Models
{
    public partial class Version
    {
        public string? SVersion { get; set; }
    }
}
