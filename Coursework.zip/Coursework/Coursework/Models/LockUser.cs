﻿using System;
using System.Collections.Generic;

namespace Coursework.Models
{
    public partial class LockUser
    {
        public string SUsername { get; set; } = null!;
        public string? SFullname { get; set; }
        public string? CRole { get; set; }
        public DateTime? DLastlogin { get; set; }
    }
}
