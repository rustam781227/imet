﻿using System;
using System.Collections.Generic;

namespace Coursework.Models
{
    public partial class Keyword
    {
        public decimal? NNword { get; set; }
        public string? SKword { get; set; }
        public string? STitle { get; set; }
    }
}
