﻿using System;
using System.Collections.Generic;

namespace Coursework.Models
{
    public partial class Literat
    {
        public Literat()
        {
            Crels = new HashSet<Crel>();
            DoubleExpGoms = new HashSet<DoubleExpGom>();
            DoubleExps = new HashSet<DoubleExp>();
            DoubleKrists = new HashSet<DoubleKrist>();
            DoubleOsob1s = new HashSet<DoubleOsob1>();
            DoubleOsob2s = new HashSet<DoubleOsob2>();
            DoubleUravns = new HashSet<DoubleUravn>();
            TripleExpIsoterms = new HashSet<TripleExpIsoterm>();
            TripleExpKvazs = new HashSet<TripleExpKvaz>();
            TripleKrists = new HashSet<TripleKrist>();
            TripleOsob1s = new HashSet<TripleOsob1>();
            TripleOsob2s = new HashSet<TripleOsob2>();
        }

        public decimal NNom { get; set; }
        public string? SFio { get; set; }
        public string? SJournal { get; set; }
        public string? SYear { get; set; }
        public string? STom { get; set; }
        public string? SNjournal { get; set; }
        public string? SFirst { get; set; }
        public string? SEnd { get; set; }
        public string? STitle { get; set; }
        public string? SOrg { get; set; }
        public string? SCountry { get; set; }
        public string? SNwords { get; set; }

        public virtual ICollection<Crel> Crels { get; set; }
        public virtual ICollection<DoubleExpGom> DoubleExpGoms { get; set; }
        public virtual ICollection<DoubleExp> DoubleExps { get; set; }
        public virtual ICollection<DoubleKrist> DoubleKrists { get; set; }
        public virtual ICollection<DoubleOsob1> DoubleOsob1s { get; set; }
        public virtual ICollection<DoubleOsob2> DoubleOsob2s { get; set; }
        public virtual ICollection<DoubleUravn> DoubleUravns { get; set; }
        public virtual ICollection<TripleExpIsoterm> TripleExpIsoterms { get; set; }
        public virtual ICollection<TripleExpKvaz> TripleExpKvazs { get; set; }
        public virtual ICollection<TripleKrist> TripleKrists { get; set; }
        public virtual ICollection<TripleOsob1> TripleOsob1s { get; set; }
        public virtual ICollection<TripleOsob2> TripleOsob2s { get; set; }
    }
}
