﻿using System;
using System.Collections.Generic;

namespace Coursework.Models
{
    public partial class UserCompound
    {
        public string? SUsername { get; set; }
        public string? SCompoundName { get; set; }
    }
}
