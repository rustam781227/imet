﻿using System;
using System.Collections.Generic;

namespace Coursework.Models
{
    public partial class JournalIndex
    {
        public string? SJournal { get; set; }
    }
}
