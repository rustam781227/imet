﻿using System;
using System.Collections.Generic;

namespace Coursework.Models
{
    public partial class Propertygate
    {
        public decimal NPropertyId { get; set; }
        public decimal NCompoundDimension { get; set; }
        public string? SRedirect2page { get; set; }
    }
}
