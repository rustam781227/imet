﻿using System;
using System.Collections.Generic;

namespace Coursework.Models
{
    public partial class TripleExp
    {
        public string SEl1 { get; set; } = null!;
        public string SEl2 { get; set; } = null!;
        public string SEl3 { get; set; } = null!;
        public string? SExpert { get; set; }
        public decimal? NSys { get; set; }
        public string? SEl1Sys1 { get; set; }
        public string? SEl2Sys1 { get; set; }
        public string? SEl1Sys2 { get; set; }
        public string? SEl2Sys2 { get; set; }
        public string? SEl1Sys3 { get; set; }
        public string? SEl2Sys3 { get; set; }
        public string? STerm { get; set; }
        public string? SCompoundName { get; set; }
    }
}
