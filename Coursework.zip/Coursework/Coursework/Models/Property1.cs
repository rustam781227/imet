﻿using System;
using System.Collections.Generic;

namespace Coursework.Models
{
    public partial class Property1
    {
        public decimal NPropertyId { get; set; }
        public string? SName { get; set; }
        public string? STablenames { get; set; }
        public string? SCompoundCols { get; set; }
        public string? SPropertyCols { get; set; }
    }
}
