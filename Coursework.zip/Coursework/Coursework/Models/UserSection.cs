﻿using System;
using System.Collections.Generic;

namespace Coursework.Models
{
    public partial class UserSection
    {
        public string? SUsername { get; set; }
        public string? SSectionId { get; set; }
    }
}
