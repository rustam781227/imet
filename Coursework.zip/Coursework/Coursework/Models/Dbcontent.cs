﻿using System;
using System.Collections.Generic;

namespace Coursework.Models
{
    public partial class Dbcontent
    {
        public decimal Headclue { get; set; }
        public decimal Nomprop { get; set; }
        public decimal Updatestatus { get; set; }

        public virtual Headtabl HeadclueNavigation { get; set; } = null!;
        public virtual Property NompropNavigation { get; set; } = null!;
    }
}
