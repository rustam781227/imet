﻿using System;
using System.Collections.Generic;

namespace Coursework.Models
{
    public partial class Webhit
    {
        public string SUsername { get; set; } = null!;
        public decimal? NHits { get; set; }
        public DateTime? DLastdate { get; set; }
    }
}
