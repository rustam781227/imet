﻿using System;
using System.Collections.Generic;

namespace Coursework.Models
{
    public partial class Dbinfo
    {
        public string Name { get; set; } = null!;
        public string Dburl { get; set; } = null!;
        public string? Dbgateurl { get; set; }
        public string Emailmanager { get; set; } = null!;
        public string Wwwtemplatepage { get; set; } = null!;
        public string Description { get; set; } = null!;
        public decimal Updatestatus { get; set; }
    }
}
