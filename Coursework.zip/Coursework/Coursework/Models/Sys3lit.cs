﻿using System;
using System.Collections.Generic;

namespace Coursework.Models
{
    public partial class Sys3lit
    {
        public string SEl1 { get; set; } = null!;
        public string SEl2 { get; set; } = null!;
        public string SEl3 { get; set; } = null!;
        public string? LNoms { get; set; }
        public string SEl { get; set; } = null!;
        public string? SRecenz { get; set; }
        public string? SUrov { get; set; }
    }
}
