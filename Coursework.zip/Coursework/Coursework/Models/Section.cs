﻿using System;
using System.Collections.Generic;

namespace Coursework.Models
{
    public partial class Section
    {
        public string SSectionId { get; set; } = null!;
        public string? SSectionName { get; set; }
    }
}
