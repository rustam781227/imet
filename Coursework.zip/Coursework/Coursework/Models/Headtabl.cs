﻿using System;
using System.Collections.Generic;

namespace Coursework.Models
{
    public partial class Headtabl
    {
        public Headtabl()
        {
            Dbcontents = new HashSet<Dbcontent>();
        }

        public decimal Headclue { get; set; }
        public decimal Updatestatus { get; set; }
        public string? System { get; set; }
        public string? Expert { get; set; }
        public string? Help { get; set; }

        public virtual ICollection<Dbcontent> Dbcontents { get; set; }
    }
}
