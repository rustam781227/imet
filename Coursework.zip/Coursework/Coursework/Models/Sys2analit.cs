﻿using System;
using System.Collections.Generic;

namespace Coursework.Models
{
    public partial class Sys2analit
    {
        public string? SEl1 { get; set; }
        public string? SEl2 { get; set; }
        public string? SEl { get; set; }
        public string? LHtml { get; set; }
    }
}
