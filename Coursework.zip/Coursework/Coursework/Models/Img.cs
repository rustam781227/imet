﻿using System;
using System.Collections.Generic;

namespace Coursework.Models
{
    public partial class Img
    {
        public decimal? Id { get; set; }
        public byte[]? Pic { get; set; }
    }
}
