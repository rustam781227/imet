﻿using System;
using System.Collections.Generic;

namespace Coursework.Models
{
    public partial class TripleExpIsoterm
    {
        public decimal NCount { get; set; }
        public string? SEl1 { get; set; }
        public string? SEl2 { get; set; }
        public string? SEl3 { get; set; }
        public double? NTemperatura { get; set; }
        public double? NNumb { get; set; }
        public double? NX { get; set; }
        public double? NPogr1 { get; set; }
        public double? NY { get; set; }
        public double? NPogr2 { get; set; }
        public decimal? NNom { get; set; }
        public string? SCompoundName { get; set; }

        public virtual Literat? NNomNavigation { get; set; }
    }
}
