﻿using System;
using System.Collections.Generic;

namespace Coursework.Models
{
    public partial class OnlineUser
    {
        public string SUsername { get; set; } = null!;
        public string? SFullname { get; set; }
        public string? CRole { get; set; }
        public DateTime? DLastlogin { get; set; }
    }
}
