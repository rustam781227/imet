﻿using System;
using System.Collections.Generic;

namespace Coursework.Models
{
    public partial class TripleUrov
    {
        public string? SUrov { get; set; }
        public decimal NUrov { get; set; }
    }
}
