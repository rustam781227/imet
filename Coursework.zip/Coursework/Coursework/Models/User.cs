﻿using System;
using System.Collections.Generic;

namespace Coursework.Models
{
    public partial class User
    {
        public decimal NUserId { get; set; }
        public string SUsername { get; set; } = null!;
        public string? SPassword { get; set; }
        public string? CRole { get; set; }
        public string? SFullname { get; set; }
        public string? SOrg { get; set; }
        public string? SAddress { get; set; }
        public string? SCountry { get; set; }
        public string? STelfax { get; set; }
        public string? SMail { get; set; }
        public DateTime? DLastlogin { get; set; }
        public DateTime? DExprise { get; set; }
        public decimal? NStarthour { get; set; }
        public decimal? NEndhour { get; set; }
        public string? SAllowedIp { get; set; }
        public DateTime? DExpiredate { get; set; }
    }
}
