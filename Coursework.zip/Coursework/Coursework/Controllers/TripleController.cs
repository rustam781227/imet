﻿using Coursework.Data;
using Microsoft.AspNetCore.Mvc;

namespace Coursework.Controllers
{
    public class TripleController : Controller
    {
        private readonly DiagrammaContext _context;
        private static string? el1;
        private static string? el2;
        private static string? el3;

        public TripleController(DiagrammaContext context)
        {
            _context = context;
        }

        // GET: TripleController
        [HttpGet]
        public IActionResult Index()
        {
            var triples = _context.Sys3lits.ToList();
            return View(triples);
        }

        [HttpPost]
        [Route("TSearchResult")]
        public IActionResult TSearchResult(string sys)
        {
            /*System.Diagnostics.Debug.WriteLine("Hello");*/
            var els = sys.Split('-');
            el1 = els[0];
            el2 = els[1];
            el3 = els[2];
            return View("TSearchResult", el1 + "-" + el2 + "-" + el3);
        }

        [Route("TFioOfExp")]
        public IActionResult TFioOfExp(string sys)
        {
            var data = _context.TripleExps.FirstOrDefault(t => t.SEl1 == el1 && t.SEl2 == el2 && t.SEl3 == el3);
            return View("TFioOfExp", data);
        }

        [Route("TAnalyticalReview")]
        public IActionResult TAnalyticalReview(string sys)
        {
            var data = _context.Sys3analits.FirstOrDefault(t => t.SEl1 == el1 && t.SEl2 == el2 && t.SEl3 == el3);
            return View("TAnalyticalReview", data);
        }

        [Route("TDrawings")]
        public IActionResult TDrawings(string sys)
        {
            var data = _context.TripleGrafs.Where(t => t.SEl1 == el1 && t.SEl2 == el2 && t.SEl3 == el3).ToList();
            return View("TDrawings", data);
        }

        [Route("ExpPointsProjSurface")]
        public IActionResult ExpPointsProjSurface(string sys)
        {
            var data = _context.TripleExpPoverhs.Where(t => t.SEl1 == el1 && t.SEl2 == el2 && t.SEl3 == el3).ToList();
            return View("ExpPointsProjSurface", data);
        }

        [Route("ConsistentPointsProjSurf")]
        public IActionResult ConsistentPointsProjSurf(string sys)
        {
            var data = _context.TripleSoglPoverhs.Where(t => t.SEl1 == el1 && t.SEl2 == el2 && t.SEl3 == el3).ToList();
            return View("ConsistentPointsProjSurf", data);
        }

        [Route("ExpPointsIsothermProj")]
        public IActionResult ExpPointsIsothermProj(string sys)
        {
            var data = _context.TripleExpIsoterms.Where(t => t.SEl1 == el1 && t.SEl2 == el2 && t.SEl3 == el3).ToList();
            return View("ExpPointsIsothermProj", data);
        }
    }
}
