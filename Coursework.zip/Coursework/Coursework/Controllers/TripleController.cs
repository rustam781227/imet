﻿using Microsoft.AspNetCore.Mvc;

namespace Coursework.Controllers
{
    public class TripleController : Controller
    {
        // GET: TripleController
        public IActionResult Index()
        {
            return View();
        }
    }
}
