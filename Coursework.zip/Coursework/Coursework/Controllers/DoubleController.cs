﻿using Coursework.Data;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;

namespace Coursework.Controllers
{
    public class DoubleController : Controller
    {
        private readonly DiagrammaContext _context;
        private string _sys;

        public DoubleController(DiagrammaContext context)
        {
            _context = context;
            _sys = "Ag-Se";
        }
        [HttpGet]
        public IActionResult Index()
        {
            var duals = _context.Sys2lits.ToList();
            return View(duals);
        }

        [HttpPost]
        [Route("searchResult")]
        public IActionResult SearchResult(string sys)
        {
            /*System.Diagnostics.Debug.WriteLine("Hello");*/
            _sys = sys;
            return View("SearchResult", sys);
        }

        [Route("FioOfExp")]
        public IActionResult FioOfExp()
        {
#pragma warning disable CS8600 // Преобразование литерала, допускающего значение NULL или возможного значения NULL в тип, не допускающий значение NULL.
            Models.Sys2lit sys = _context.Sys2lits.FirstOrDefault(s => s.SEl == _sys);
#pragma warning restore CS8600 // Преобразование литерала, допускающего значение NULL или возможного значения NULL в тип, не допускающий значение NULL.
            return View("FioOfExp", sys);
        }
    }
}
