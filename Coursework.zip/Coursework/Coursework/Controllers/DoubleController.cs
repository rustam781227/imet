﻿using Coursework.Data;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;

namespace Coursework.Controllers
{
    public class DoubleController : Controller
    {
        private readonly DiagrammaContext _context;
        private static string? el1;
        private static string? el2;

        public DoubleController(DiagrammaContext context)
        {
            _context = context;
        }

        [HttpGet]
        public IActionResult Index()
        {
            var duals = _context.Sys2lits.ToList();
            return View(duals);
        }


        [Route("SearchResult")]
        public IActionResult SearchResult(string? sys)
        {
            if (sys != null)
            {
                var els = sys.Split('-');
                el1 = els[0];
                el2 = els[1];
            }
            return View("SearchResult", el1 + "-" + el2);
        }

        [HttpPost]
        [Route("doubleFixed")]
        public IActionResult DoubleFixed(string first)
        {
            var systems = _context.Sys2lits.Where(system => system.SEl1 == first).ToList();
            return View("DoubleFixed", systems);
        }

        [Route("FioOfExp")]
        public IActionResult FioOfExp()
        {
#pragma warning disable CS8600 // Преобразование литерала, допускающего значение NULL или возможного значения NULL в тип, не допускающий значение NULL.
            Models.Sys2lit sys = _context.Sys2lits.FirstOrDefault(s => s.SEl1 == el1 && s.SEl2 == el2);
#pragma warning restore CS8600 // Преобразование литерала, допускающего значение NULL или возможного значения NULL в тип, не допускающий значение NULL.
            return View("FioOfExp", sys);
        }

        [Route("AnalyticalReview")]
        public IActionResult AnalyticalReview()
        {
#pragma warning disable CS8600 // Преобразование литерала, допускающего значение NULL или возможного значения NULL в тип, не допускающий значение NULL.
            Models.Sys2analit analit = _context.Sys2analits.FirstOrDefault(a => a.SEl1 == el1 && a.SEl2 == el2);
#pragma warning restore CS8600 // Преобразование литерала, допускающего значение NULL или возможного значения NULL в тип, не допускающий значение NULL.
            return View("AnalyticalReview", analit);
        }

        [Route("Drawings")]
        public IActionResult Drawings() 
        {
            var drawings = _context.DoubleGrafs.Where(d => d.SEl1 == el1 && d.SEl2 == el2).ToList();
            return View("Drawings", drawings);
        }

        [Route("ExpPointsOfDiag")]
        public IActionResult ExpPointsOfDiag()
        {
            var exp = _context.DoubleExps.Where(e => e.SEl1 == el1 && e.SEl2 == el2).ToList();
            return View("ExpPointsOfDiag", exp);
        }

        [Route("ExpGomPointsOfDiag")]
        public IActionResult ExpGomPointsOfDiag()
        {
            var exp = _context.DoubleExpGoms.Where(e => e.SEl1 == el1 && e.SEl2 == el2).ToList();
            return View("ExpGomPointsOfDiag", exp);
        }

        [Route("ConsistentDataOfDiag")]
        public IActionResult ConsistentDataOfDiag()
        {
            var data = _context.DoubleSogls.Where(d => d.SEl1 == el1 && d.SEl2 == el2).ToList();
            return View("ConsistentDataOfDiag", data);
        }

        [Route("CoeffsOfEquation")]
        public IActionResult CoeffsOfEquation()
        {
            var coeffs = _context.DoubleUravns.Where(c => c.SEl1 == el1 && c.SEl2 == el2).ToList();
            return View("CoeffsOfEquation", coeffs);
        }
    }
}
