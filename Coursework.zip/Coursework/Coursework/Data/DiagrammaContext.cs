﻿using System;
using System.Collections.Generic;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata;
using Coursework.Models;

namespace Coursework.Data
{
    public partial class DiagrammaContext : DbContext
    {
        public DiagrammaContext()
        {
        }

        public DiagrammaContext(DbContextOptions<DiagrammaContext> options)
            : base(options)
        {
        }

        public virtual DbSet<Cal> Cals { get; set; } = null!;
        public virtual DbSet<Compound> Compounds { get; set; } = null!;
        public virtual DbSet<CountryIndex> CountryIndices { get; set; } = null!;
        public virtual DbSet<Crel> Crels { get; set; } = null!;
        public virtual DbSet<Dbcontent> Dbcontents { get; set; } = null!;
        public virtual DbSet<Dbinfo> Dbinfos { get; set; } = null!;
        public virtual DbSet<DoubleExp> DoubleExps { get; set; } = null!;
        public virtual DbSet<DoubleExpGom> DoubleExpGoms { get; set; } = null!;
        public virtual DbSet<DoubleGraf> DoubleGrafs { get; set; } = null!;
        public virtual DbSet<DoubleKrist> DoubleKrists { get; set; } = null!;
        public virtual DbSet<DoubleOsob1> DoubleOsob1s { get; set; } = null!;
        public virtual DbSet<DoubleOsob2> DoubleOsob2s { get; set; } = null!;
        public virtual DbSet<DoubleSogl> DoubleSogls { get; set; } = null!;
        public virtual DbSet<DoubleUravn> DoubleUravns { get; set; } = null!;
        public virtual DbSet<DoubleUrov> DoubleUrovs { get; set; } = null!;
        public virtual DbSet<FioIndex> FioIndices { get; set; } = null!;
        public virtual DbSet<Headtabl> Headtabls { get; set; } = null!;
        public virtual DbSet<Img> Imgs { get; set; } = null!;
        public virtual DbSet<JournalIndex> JournalIndices { get; set; } = null!;
        public virtual DbSet<Keyword> Keywords { get; set; } = null!;
        public virtual DbSet<Literat> Literats { get; set; } = null!;
        public virtual DbSet<LockUser> LockUsers { get; set; } = null!;
        public virtual DbSet<OnlineUser> OnlineUsers { get; set; } = null!;
        public virtual DbSet<OrgIndex> OrgIndices { get; set; } = null!;
        public virtual DbSet<Page> Pages { get; set; } = null!;
        public virtual DbSet<Property> Properties { get; set; } = null!;
        public virtual DbSet<Property1> Properties1 { get; set; } = null!;
        public virtual DbSet<Propertygate> Propertygates { get; set; } = null!;
        public virtual DbSet<Section> Sections { get; set; } = null!;
        public virtual DbSet<Sys2analit> Sys2analits { get; set; } = null!;
        public virtual DbSet<Sys2lit> Sys2lits { get; set; } = null!;
        public virtual DbSet<Sys3analit> Sys3analits { get; set; } = null!;
        public virtual DbSet<Sys3lit> Sys3lits { get; set; } = null!;
        public virtual DbSet<Term> Terms { get; set; } = null!;
        public virtual DbSet<TripleExp> TripleExps { get; set; } = null!;
        public virtual DbSet<TripleExpIsoterm> TripleExpIsoterms { get; set; } = null!;
        public virtual DbSet<TripleExpKvaz> TripleExpKvazs { get; set; } = null!;
        public virtual DbSet<TripleExpPoverh> TripleExpPoverhs { get; set; } = null!;
        public virtual DbSet<TripleGraf> TripleGrafs { get; set; } = null!;
        public virtual DbSet<TripleKrist> TripleKrists { get; set; } = null!;
        public virtual DbSet<TripleOsob1> TripleOsob1s { get; set; } = null!;
        public virtual DbSet<TripleOsob2> TripleOsob2s { get; set; } = null!;
        public virtual DbSet<TripleSoglIsoterm> TripleSoglIsoterms { get; set; } = null!;
        public virtual DbSet<TripleSoglKvaz> TripleSoglKvazs { get; set; } = null!;
        public virtual DbSet<TripleSoglPoverh> TripleSoglPoverhs { get; set; } = null!;
        public virtual DbSet<TripleUrov> TripleUrovs { get; set; } = null!;
        public virtual DbSet<User> Users { get; set; } = null!;
        public virtual DbSet<UserCompound> UserCompounds { get; set; } = null!;
        public virtual DbSet<UserSection> UserSections { get; set; } = null!;
        public virtual DbSet<Usersinfo> Usersinfos { get; set; } = null!;
        public virtual DbSet<Models.Version> Versions { get; set; } = null!;
        public virtual DbSet<Webhit> Webhits { get; set; } = null!;

        protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
        {
            if (!optionsBuilder.IsConfigured)
            {
#warning To protect potentially sensitive information in your connection string, you should move it out of source code. You can avoid scaffolding the connection string by using the Name= syntax to read it from configuration - see https://go.microsoft.com/fwlink/?linkid=2131148. For more guidance on storing connection strings, see http://go.microsoft.com/fwlink/?LinkId=723263.
                optionsBuilder.UseSqlServer("Data Source=(localdb)\\MSSQLLocalDB;Initial Catalog=Coursework;Database=Diagramma;Trusted_Connection=True");
            }
        }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            modelBuilder.UseCollation("Cyrillic_General_CI_AS");

            modelBuilder.Entity<Cal>(entity =>
            {
                entity.HasKey(e => e.SEl);

                entity.ToTable("CAL", "DIAG");

                entity.Property(e => e.SEl)
                    .HasMaxLength(30)
                    .IsUnicode(false)
                    .HasColumnName("S_EL");

                entity.Property(e => e.LHtml)
                    .HasColumnType("text")
                    .HasColumnName("L_HTML");

                entity.Property(e => e.NNum)
                    .HasColumnType("numeric(38, 0)")
                    .HasColumnName("N_NUM");
            });

            modelBuilder.Entity<Compound>(entity =>
            {
                entity.HasKey(e => e.SCompoundName);

                entity.ToTable("COMPOUNDS", "DIAG");

                entity.Property(e => e.SCompoundName)
                    .HasMaxLength(255)
                    .IsUnicode(false)
                    .HasColumnName("S_COMPOUND_NAME");

                entity.Property(e => e.NCompoundDimension)
                    .HasColumnType("numeric(38, 0)")
                    .HasColumnName("N_COMPOUND_DIMENSION");

                entity.Property(e => e.NCompoundid)
                    .HasColumnType("numeric(10, 0)")
                    .HasColumnName("N_COMPOUNDID");

                entity.Property(e => e.SElem1)
                    .HasMaxLength(2)
                    .IsUnicode(false)
                    .HasColumnName("S_ELEM1");

                entity.Property(e => e.SElem2)
                    .HasMaxLength(2)
                    .IsUnicode(false)
                    .HasColumnName("S_ELEM2");

                entity.Property(e => e.SElem3)
                    .HasMaxLength(2)
                    .IsUnicode(false)
                    .HasColumnName("S_ELEM3");
            });

            modelBuilder.Entity<CountryIndex>(entity =>
            {
                entity.HasNoKey();

                entity.ToTable("COUNTRY_INDEX", "DIAG");

                entity.Property(e => e.SCountry)
                    .HasMaxLength(1500)
                    .IsUnicode(false)
                    .HasColumnName("S_COUNTRY");
            });

            modelBuilder.Entity<Crel>(entity =>
            {
                entity.HasKey(e => e.NCount);

                entity.ToTable("CREL", "DIAG");

                entity.Property(e => e.NCount)
                    .HasColumnType("numeric(38, 0)")
                    .HasColumnName("N_COUNT");

                entity.Property(e => e.NA).HasColumnName("N_A");

                entity.Property(e => e.NAlpha).HasColumnName("N_ALPHA");

                entity.Property(e => e.NB).HasColumnName("N_B");

                entity.Property(e => e.NBeta).HasColumnName("N_BETA");

                entity.Property(e => e.NC).HasColumnName("N_C");

                entity.Property(e => e.NGamma).HasColumnName("N_GAMMA");

                entity.Property(e => e.NNom)
                    .HasColumnType("numeric(38, 0)")
                    .HasColumnName("N_NOM");

                entity.Property(e => e.NPogr1).HasColumnName("N_POGR1");

                entity.Property(e => e.NPogr2).HasColumnName("N_POGR2");

                entity.Property(e => e.NPogr3).HasColumnName("N_POGR3");

                entity.Property(e => e.NPogr4).HasColumnName("N_POGR4");

                entity.Property(e => e.NPogr5).HasColumnName("N_POGR5");

                entity.Property(e => e.NPogr6).HasColumnName("N_POGR6");

                entity.Property(e => e.SEl)
                    .HasMaxLength(40)
                    .IsUnicode(false)
                    .HasColumnName("S_EL");

                entity.Property(e => e.SFaza)
                    .HasMaxLength(64)
                    .IsUnicode(false)
                    .HasColumnName("S_FAZA");

                entity.Property(e => e.SPirson)
                    .HasMaxLength(128)
                    .IsUnicode(false)
                    .HasColumnName("S_PIRSON");

                entity.Property(e => e.SSpgr)
                    .HasMaxLength(128)
                    .IsUnicode(false)
                    .HasColumnName("S_SPGR");

                entity.Property(e => e.STitle)
                    .HasMaxLength(1024)
                    .IsUnicode(false)
                    .HasColumnName("S_TITLE");

                entity.Property(e => e.STypestr)
                    .HasMaxLength(128)
                    .IsUnicode(false)
                    .HasColumnName("S_TYPESTR");

                entity.HasOne(d => d.NNomNavigation)
                    .WithMany(p => p.Crels)
                    .HasForeignKey(d => d.NNom)
                    .HasConstraintName("FK_CREL_LITERAT");
            });

            modelBuilder.Entity<Dbcontent>(entity =>
            {
                entity.HasKey(e => new { e.Headclue, e.Nomprop });

                entity.ToTable("_DBCONTENT", "DIAG");

                entity.Property(e => e.Headclue)
                    .HasColumnType("numeric(10, 0)")
                    .HasColumnName("HEADCLUE");

                entity.Property(e => e.Nomprop)
                    .HasColumnType("numeric(10, 0)")
                    .HasColumnName("NOMPROP");

                entity.Property(e => e.Updatestatus)
                    .HasColumnType("numeric(38, 0)")
                    .HasColumnName("UPDATESTATUS");

                entity.HasOne(d => d.HeadclueNavigation)
                    .WithMany(p => p.Dbcontents)
                    .HasForeignKey(d => d.Headclue)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK__DBCONTENT__HEADTABL");

                entity.HasOne(d => d.NompropNavigation)
                    .WithMany(p => p.Dbcontents)
                    .HasForeignKey(d => d.Nomprop)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK__DBCONTENT__PROPERTIES");
            });

            modelBuilder.Entity<Dbinfo>(entity =>
            {
                entity.HasKey(e => e.Name);

                entity.ToTable("_DBINFO", "DIAG");

                entity.Property(e => e.Name)
                    .HasMaxLength(128)
                    .IsUnicode(false)
                    .HasColumnName("NAME");

                entity.Property(e => e.Dbgateurl)
                    .HasMaxLength(255)
                    .IsUnicode(false)
                    .HasColumnName("DBGATEURL");

                entity.Property(e => e.Dburl)
                    .HasMaxLength(128)
                    .IsUnicode(false)
                    .HasColumnName("DBURL");

                entity.Property(e => e.Description)
                    .HasMaxLength(255)
                    .IsUnicode(false)
                    .HasColumnName("DESCRIPTION");

                entity.Property(e => e.Emailmanager)
                    .HasMaxLength(64)
                    .IsUnicode(false)
                    .HasColumnName("EMAILMANAGER");

                entity.Property(e => e.Updatestatus)
                    .HasColumnType("numeric(1, 0)")
                    .HasColumnName("UPDATESTATUS");

                entity.Property(e => e.Wwwtemplatepage)
                    .HasMaxLength(128)
                    .IsUnicode(false)
                    .HasColumnName("WWWTEMPLATEPAGE");
            });

            modelBuilder.Entity<DoubleExp>(entity =>
            {
                entity.HasKey(e => e.NCount);

                entity.ToTable("DOUBLE_EXP", "DIAG");

                entity.Property(e => e.NCount).HasColumnName("N_COUNT");

                entity.Property(e => e.NNom)
                    .HasColumnType("numeric(38, 0)")
                    .HasColumnName("N_NOM");

                entity.Property(e => e.NNumb).HasColumnName("N_NUMB");

                entity.Property(e => e.NPogr1).HasColumnName("N_POGR1");

                entity.Property(e => e.NPogr2).HasColumnName("N_POGR2");

                entity.Property(e => e.NPogr3).HasColumnName("N_POGR3");

                entity.Property(e => e.NPress).HasColumnName("N_PRESS");

                entity.Property(e => e.NTemperatura).HasColumnName("N_TEMPERATURA");

                entity.Property(e => e.NX).HasColumnName("N_X");

                entity.Property(e => e.SCompoundName)
                    .HasMaxLength(255)
                    .IsUnicode(false)
                    .HasColumnName("S_COMPOUND_NAME");

                entity.Property(e => e.SEl1)
                    .HasMaxLength(4)
                    .IsUnicode(false)
                    .HasColumnName("S_EL1");

                entity.Property(e => e.SEl2)
                    .HasMaxLength(4)
                    .IsUnicode(false)
                    .HasColumnName("S_EL2");

                entity.Property(e => e.SLine)
                    .HasMaxLength(50)
                    .IsUnicode(false)
                    .HasColumnName("S_LINE");

                entity.HasOne(d => d.NNomNavigation)
                    .WithMany(p => p.DoubleExps)
                    .HasForeignKey(d => d.NNom)
                    .HasConstraintName("FK_DOUBLE_EXP_LITERAT");
            });

            modelBuilder.Entity<DoubleExpGom>(entity =>
            {
                entity.HasKey(e => e.NCount);

                entity.ToTable("DOUBLE_EXP_GOM", "DIAG");

                entity.Property(e => e.NCount)
                    .HasColumnType("numeric(38, 0)")
                    .HasColumnName("N_COUNT");

                entity.Property(e => e.NKonc).HasColumnName("N_KONC");

                entity.Property(e => e.NNom)
                    .HasColumnType("numeric(38, 0)")
                    .HasColumnName("N_NOM");

                entity.Property(e => e.NNumb).HasColumnName("N_NUMB");

                entity.Property(e => e.NPogr1).HasColumnName("N_POGR1");

                entity.Property(e => e.NPogr2).HasColumnName("N_POGR2");

                entity.Property(e => e.NPogr3).HasColumnName("N_POGR3");

                entity.Property(e => e.NPress).HasColumnName("N_PRESS");

                entity.Property(e => e.NTemperatura).HasColumnName("N_TEMPERATURA");

                entity.Property(e => e.SCompoundName)
                    .HasMaxLength(256)
                    .IsUnicode(false)
                    .HasColumnName("S_COMPOUND_NAME");

                entity.Property(e => e.SEl1)
                    .HasMaxLength(10)
                    .IsUnicode(false)
                    .HasColumnName("S_EL1");

                entity.Property(e => e.SEl2)
                    .HasMaxLength(10)
                    .IsUnicode(false)
                    .HasColumnName("S_EL2");

                entity.Property(e => e.SElIsb)
                    .HasMaxLength(10)
                    .IsUnicode(false)
                    .HasColumnName("S_EL_ISB");

                entity.Property(e => e.SFaza)
                    .HasMaxLength(64)
                    .IsUnicode(false)
                    .HasColumnName("S_FAZA");

                entity.Property(e => e.SLine)
                    .HasMaxLength(64)
                    .IsUnicode(false)
                    .HasColumnName("S_LINE");

                entity.Property(e => e.SPar)
                    .HasMaxLength(64)
                    .IsUnicode(false)
                    .HasColumnName("S_PAR");

                entity.Property(e => e.SProvod)
                    .HasMaxLength(10)
                    .IsUnicode(false)
                    .HasColumnName("S_PROVOD");

                entity.HasOne(d => d.NNomNavigation)
                    .WithMany(p => p.DoubleExpGoms)
                    .HasForeignKey(d => d.NNom)
                    .HasConstraintName("FK_DOUBLE_EXP_GOM_LITERAT");
            });

            modelBuilder.Entity<DoubleGraf>(entity =>
            {
                entity.HasKey(e => e.NCount);

                entity.ToTable("DOUBLE_GRAF", "DIAG");

                entity.Property(e => e.NCount)
                    .HasColumnType("numeric(38, 0)")
                    .HasColumnName("N_COUNT");

                entity.Property(e => e.LImg)
                    .HasColumnType("image")
                    .HasColumnName("L_IMG");

                entity.Property(e => e.SCompoundName)
                    .HasMaxLength(255)
                    .IsUnicode(false)
                    .HasColumnName("S_COMPOUND_NAME");

                entity.Property(e => e.SEl1)
                    .HasMaxLength(10)
                    .IsUnicode(false)
                    .HasColumnName("S_EL1");

                entity.Property(e => e.SEl2)
                    .HasMaxLength(10)
                    .IsUnicode(false)
                    .HasColumnName("S_EL2");

                entity.Property(e => e.STitle)
                    .HasMaxLength(500)
                    .IsUnicode(false)
                    .HasColumnName("S_TITLE");
            });

            modelBuilder.Entity<DoubleKrist>(entity =>
            {
                entity.HasKey(e => e.NCount);

                entity.ToTable("DOUBLE_KRIST", "DIAG");

                entity.Property(e => e.NCount)
                    .HasColumnType("numeric(38, 0)")
                    .HasColumnName("N_COUNT");

                entity.Property(e => e.NA).HasColumnName("N_A");

                entity.Property(e => e.NAlpha).HasColumnName("N_ALPHA");

                entity.Property(e => e.NB).HasColumnName("N_B");

                entity.Property(e => e.NBeta).HasColumnName("N_BETA");

                entity.Property(e => e.NC).HasColumnName("N_C");

                entity.Property(e => e.NGamma).HasColumnName("N_GAMMA");

                entity.Property(e => e.NNom)
                    .HasColumnType("numeric(38, 0)")
                    .HasColumnName("N_NOM");

                entity.Property(e => e.NPogr1).HasColumnName("N_POGR1");

                entity.Property(e => e.NPogr2).HasColumnName("N_POGR2");

                entity.Property(e => e.NPogr3).HasColumnName("N_POGR3");

                entity.Property(e => e.NPogr4).HasColumnName("N_POGR4");

                entity.Property(e => e.NPogr5).HasColumnName("N_POGR5");

                entity.Property(e => e.NPogr6).HasColumnName("N_POGR6");

                entity.Property(e => e.SCompoundName)
                    .HasMaxLength(256)
                    .IsUnicode(false)
                    .HasColumnName("S_COMPOUND_NAME");

                entity.Property(e => e.SEl1)
                    .HasMaxLength(10)
                    .IsUnicode(false)
                    .HasColumnName("S_EL1");

                entity.Property(e => e.SEl2)
                    .HasMaxLength(10)
                    .IsUnicode(false)
                    .HasColumnName("S_EL2");

                entity.Property(e => e.SFaza)
                    .HasMaxLength(64)
                    .IsUnicode(false)
                    .HasColumnName("S_FAZA");

                entity.Property(e => e.SPirson)
                    .HasMaxLength(128)
                    .IsUnicode(false)
                    .HasColumnName("S_PIRSON");

                entity.Property(e => e.SSpgr)
                    .HasMaxLength(128)
                    .IsUnicode(false)
                    .HasColumnName("S_SPGR");

                entity.Property(e => e.STitle)
                    .HasMaxLength(1024)
                    .IsUnicode(false)
                    .HasColumnName("S_TITLE");

                entity.Property(e => e.STypestr)
                    .HasMaxLength(128)
                    .IsUnicode(false)
                    .HasColumnName("S_TYPESTR");

                entity.HasOne(d => d.NNomNavigation)
                    .WithMany(p => p.DoubleKrists)
                    .HasForeignKey(d => d.NNom)
                    .HasConstraintName("FK_DOUBLE_KRIST_LITERAT");
            });

            modelBuilder.Entity<DoubleOsob1>(entity =>
            {
                entity.HasKey(e => e.NCount);

                entity.ToTable("DOUBLE_OSOB1", "DIAG");

                entity.Property(e => e.NCount)
                    .HasColumnType("numeric(38, 0)")
                    .HasColumnName("N_COUNT");

                entity.Property(e => e.NNom)
                    .HasColumnType("numeric(38, 0)")
                    .HasColumnName("N_NOM");

                entity.Property(e => e.NPogr1).HasColumnName("N_POGR1");

                entity.Property(e => e.NPogr2).HasColumnName("N_POGR2");

                entity.Property(e => e.NPress).HasColumnName("N_PRESS");

                entity.Property(e => e.NTemperatura).HasColumnName("N_TEMPERATURA");

                entity.Property(e => e.SCompoundName)
                    .HasMaxLength(256)
                    .IsUnicode(false)
                    .HasColumnName("S_COMPOUND_NAME");

                entity.Property(e => e.SEl1)
                    .HasMaxLength(10)
                    .IsUnicode(false)
                    .HasColumnName("S_EL1");

                entity.Property(e => e.SEl2)
                    .HasMaxLength(10)
                    .IsUnicode(false)
                    .HasColumnName("S_EL2");

                entity.Property(e => e.SReak)
                    .HasMaxLength(300)
                    .IsUnicode(false)
                    .HasColumnName("S_REAK");

                entity.Property(e => e.STitle)
                    .HasMaxLength(1536)
                    .IsUnicode(false)
                    .HasColumnName("S_TITLE");

                entity.Property(e => e.SType)
                    .HasMaxLength(64)
                    .IsUnicode(false)
                    .HasColumnName("S_TYPE");

                entity.HasOne(d => d.NNomNavigation)
                    .WithMany(p => p.DoubleOsob1s)
                    .HasForeignKey(d => d.NNom)
                    .HasConstraintName("FK_DOUBLE_OSOB1_LITERAT");
            });

            modelBuilder.Entity<DoubleOsob2>(entity =>
            {
                entity.HasKey(e => e.NCount);

                entity.ToTable("DOUBLE_OSOB2", "DIAG");

                entity.Property(e => e.NCount)
                    .HasColumnType("numeric(38, 0)")
                    .HasColumnName("N_COUNT");

                entity.Property(e => e.NNom)
                    .HasColumnType("numeric(38, 0)")
                    .HasColumnName("N_NOM");

                entity.Property(e => e.NPogr).HasColumnName("N_POGR");

                entity.Property(e => e.NX).HasColumnName("N_X");

                entity.Property(e => e.SEl1)
                    .HasMaxLength(10)
                    .IsUnicode(false)
                    .HasColumnName("S_EL1");

                entity.Property(e => e.SEl2)
                    .HasMaxLength(10)
                    .IsUnicode(false)
                    .HasColumnName("S_EL2");

                entity.Property(e => e.SFaza)
                    .HasMaxLength(60)
                    .IsUnicode(false)
                    .HasColumnName("S_FAZA");

                entity.Property(e => e.SReak)
                    .HasMaxLength(300)
                    .IsUnicode(false)
                    .HasColumnName("S_REAK");

                entity.HasOne(d => d.NNomNavigation)
                    .WithMany(p => p.DoubleOsob2s)
                    .HasForeignKey(d => d.NNom)
                    .HasConstraintName("FK_DOUBLE_OSOB2_LITERAT");
            });

            modelBuilder.Entity<DoubleSogl>(entity =>
            {
                entity.HasKey(e => e.NCount);

                entity.ToTable("DOUBLE_SOGL", "DIAG");

                entity.Property(e => e.NCount).HasColumnName("N_COUNT");

                entity.Property(e => e.NNumb).HasColumnName("N_NUMB");

                entity.Property(e => e.NPogr1).HasColumnName("N_POGR1");

                entity.Property(e => e.NPogr2).HasColumnName("N_POGR2");

                entity.Property(e => e.NPress).HasColumnName("N_PRESS");

                entity.Property(e => e.NTemperatura).HasColumnName("N_TEMPERATURA");

                entity.Property(e => e.NX).HasColumnName("N_X");

                entity.Property(e => e.SCompoundName)
                    .HasMaxLength(255)
                    .IsUnicode(false)
                    .HasColumnName("S_COMPOUND_NAME");

                entity.Property(e => e.SEl1)
                    .HasMaxLength(10)
                    .IsUnicode(false)
                    .HasColumnName("S_EL1");

                entity.Property(e => e.SEl2)
                    .HasMaxLength(10)
                    .IsUnicode(false)
                    .HasColumnName("S_EL2");

                entity.Property(e => e.SLine)
                    .HasMaxLength(50)
                    .IsUnicode(false)
                    .HasColumnName("S_LINE");
            });

            modelBuilder.Entity<DoubleUravn>(entity =>
            {
                entity.HasKey(e => e.NCount);

                entity.ToTable("DOUBLE_URAVN", "DIAG");

                entity.Property(e => e.NCount)
                    .HasColumnType("numeric(38, 0)")
                    .HasColumnName("N_COUNT");

                entity.Property(e => e.NA).HasColumnName("N_A");

                entity.Property(e => e.NB).HasColumnName("N_B");

                entity.Property(e => e.NNom)
                    .HasColumnType("numeric(38, 0)")
                    .HasColumnName("N_NOM");

                entity.Property(e => e.NNumb).HasColumnName("N_NUMB");

                entity.Property(e => e.NPogr1).HasColumnName("N_POGR1");

                entity.Property(e => e.NPogr2).HasColumnName("N_POGR2");

                entity.Property(e => e.NPogr3).HasColumnName("N_POGR3");

                entity.Property(e => e.NTEnd).HasColumnName("N_T_END");

                entity.Property(e => e.NTFirst).HasColumnName("N_T_FIRST");

                entity.Property(e => e.NX).HasColumnName("N_X");

                entity.Property(e => e.SCompoundName)
                    .HasMaxLength(256)
                    .IsUnicode(false)
                    .HasColumnName("S_COMPOUND_NAME");

                entity.Property(e => e.SEl1)
                    .HasMaxLength(4)
                    .IsUnicode(false)
                    .HasColumnName("S_EL1");

                entity.Property(e => e.SEl2)
                    .HasMaxLength(4)
                    .IsUnicode(false)
                    .HasColumnName("S_EL2");

                entity.Property(e => e.SFaza)
                    .HasMaxLength(64)
                    .IsUnicode(false)
                    .HasColumnName("S_FAZA");

                entity.HasOne(d => d.NNomNavigation)
                    .WithMany(p => p.DoubleUravns)
                    .HasForeignKey(d => d.NNom)
                    .HasConstraintName("FK_DOUBLE_URAVN_LITERAT");
            });

            modelBuilder.Entity<DoubleUrov>(entity =>
            {
                entity.HasKey(e => e.NUrov);

                entity.ToTable("DOUBLE_UROV", "DIAG");

                entity.Property(e => e.NUrov)
                    .HasColumnType("numeric(38, 0)")
                    .HasColumnName("N_UROV");

                entity.Property(e => e.SUrov)
                    .HasMaxLength(2000)
                    .IsUnicode(false)
                    .HasColumnName("S_UROV");
            });

            modelBuilder.Entity<FioIndex>(entity =>
            {
                entity.HasNoKey();

                entity.ToTable("FIO_INDEX", "DIAG");

                entity.Property(e => e.SFio)
                    .HasMaxLength(1500)
                    .IsUnicode(false)
                    .HasColumnName("S_FIO");
            });

            modelBuilder.Entity<Headtabl>(entity =>
            {
                entity.HasKey(e => e.Headclue);

                entity.ToTable("_HEADTABL", "DIAG");

                entity.Property(e => e.Headclue)
                    .HasColumnType("numeric(10, 0)")
                    .HasColumnName("HEADCLUE");

                entity.Property(e => e.Expert)
                    .HasMaxLength(40)
                    .IsUnicode(false)
                    .HasColumnName("EXPERT");

                entity.Property(e => e.Help)
                    .HasMaxLength(40)
                    .IsUnicode(false)
                    .HasColumnName("HELP");

                entity.Property(e => e.System)
                    .HasMaxLength(60)
                    .IsUnicode(false)
                    .HasColumnName("SYSTEM");

                entity.Property(e => e.Updatestatus)
                    .HasColumnType("numeric(1, 0)")
                    .HasColumnName("UPDATESTATUS");
            });

            modelBuilder.Entity<Img>(entity =>
            {
                entity.HasNoKey();

                entity.ToTable("IMG", "DIAG");

                entity.Property(e => e.Id)
                    .HasColumnType("numeric(38, 0)")
                    .HasColumnName("ID");

                entity.Property(e => e.Pic)
                    .HasColumnType("image")
                    .HasColumnName("PIC");
            });

            modelBuilder.Entity<JournalIndex>(entity =>
            {
                entity.HasNoKey();

                entity.ToTable("JOURNAL_INDEX", "DIAG");

                entity.Property(e => e.SJournal)
                    .HasMaxLength(1500)
                    .IsUnicode(false)
                    .HasColumnName("S_JOURNAL");
            });

            modelBuilder.Entity<Keyword>(entity =>
            {
                entity.HasNoKey();

                entity.ToTable("KEYWORDS", "DIAG");

                entity.Property(e => e.NNword)
                    .HasColumnType("numeric(38, 0)")
                    .HasColumnName("N_NWORD");

                entity.Property(e => e.SKword)
                    .HasMaxLength(30)
                    .IsUnicode(false)
                    .HasColumnName("S_KWORD");

                entity.Property(e => e.STitle)
                    .HasMaxLength(200)
                    .IsUnicode(false)
                    .HasColumnName("S_TITLE");
            });

            modelBuilder.Entity<Literat>(entity =>
            {
                entity.HasKey(e => e.NNom);

                entity.ToTable("LITERAT", "DIAG");

                entity.Property(e => e.NNom)
                    .HasColumnType("numeric(38, 0)")
                    .HasColumnName("N_NOM");

                entity.Property(e => e.SCountry)
                    .HasMaxLength(1500)
                    .IsUnicode(false)
                    .HasColumnName("S_COUNTRY");

                entity.Property(e => e.SEnd)
                    .HasMaxLength(300)
                    .IsUnicode(false)
                    .HasColumnName("S_END");

                entity.Property(e => e.SFio)
                    .HasMaxLength(1500)
                    .IsUnicode(false)
                    .HasColumnName("S_FIO");

                entity.Property(e => e.SFirst)
                    .HasMaxLength(300)
                    .IsUnicode(false)
                    .HasColumnName("S_FIRST");

                entity.Property(e => e.SJournal)
                    .HasMaxLength(1500)
                    .IsUnicode(false)
                    .HasColumnName("S_JOURNAL");

                entity.Property(e => e.SNjournal)
                    .HasMaxLength(300)
                    .IsUnicode(false)
                    .HasColumnName("S_NJOURNAL");

                entity.Property(e => e.SNwords)
                    .HasMaxLength(500)
                    .IsUnicode(false)
                    .HasColumnName("S_NWORDS");

                entity.Property(e => e.SOrg)
                    .HasMaxLength(2000)
                    .IsUnicode(false)
                    .HasColumnName("S_ORG");

                entity.Property(e => e.STitle)
                    .HasMaxLength(2000)
                    .IsUnicode(false)
                    .HasColumnName("S_TITLE");

                entity.Property(e => e.STom)
                    .HasMaxLength(300)
                    .IsUnicode(false)
                    .HasColumnName("S_TOM");

                entity.Property(e => e.SYear)
                    .HasMaxLength(500)
                    .IsUnicode(false)
                    .HasColumnName("S_YEAR");
            });

            modelBuilder.Entity<LockUser>(entity =>
            {
                entity.HasNoKey();

                entity.ToTable("LOCK_USERS", "DIAG");

                entity.Property(e => e.CRole)
                    .HasMaxLength(4)
                    .IsUnicode(false)
                    .HasColumnName("C_ROLE")
                    .IsFixedLength();

                entity.Property(e => e.DLastlogin)
                    .HasColumnType("datetime")
                    .HasColumnName("D_LASTLOGIN");

                entity.Property(e => e.SFullname)
                    .HasMaxLength(100)
                    .IsUnicode(false)
                    .HasColumnName("S_FULLNAME");

                entity.Property(e => e.SUsername)
                    .HasMaxLength(10)
                    .IsUnicode(false)
                    .HasColumnName("S_USERNAME");
            });

            modelBuilder.Entity<OnlineUser>(entity =>
            {
                entity.HasKey(e => e.SUsername);

                entity.ToTable("ONLINE_USERS", "DIAG");

                entity.Property(e => e.SUsername)
                    .HasMaxLength(10)
                    .IsUnicode(false)
                    .HasColumnName("S_USERNAME");

                entity.Property(e => e.CRole)
                    .HasMaxLength(4)
                    .IsUnicode(false)
                    .HasColumnName("C_ROLE")
                    .IsFixedLength();

                entity.Property(e => e.DLastlogin)
                    .HasColumnType("datetime")
                    .HasColumnName("D_LASTLOGIN");

                entity.Property(e => e.SFullname)
                    .HasMaxLength(100)
                    .IsUnicode(false)
                    .HasColumnName("S_FULLNAME");
            });

            modelBuilder.Entity<OrgIndex>(entity =>
            {
                entity.HasNoKey();

                entity.ToTable("ORG_INDEX", "DIAG");

                entity.Property(e => e.SOrg)
                    .HasMaxLength(1500)
                    .IsUnicode(false)
                    .HasColumnName("S_ORG");
            });

            modelBuilder.Entity<Page>(entity =>
            {
                entity.HasNoKey();

                entity.ToTable("PAGES", "DIAG");

                entity.Property(e => e.SPageFilename)
                    .HasMaxLength(30)
                    .IsUnicode(false)
                    .HasColumnName("S_PAGE_FILENAME");
            });

            modelBuilder.Entity<Property>(entity =>
            {
                entity.HasKey(e => e.Nomprop);

                entity.ToTable("_PROPERTIES", "DIAG");

                entity.Property(e => e.Nomprop)
                    .HasColumnType("numeric(10, 0)")
                    .HasColumnName("NOMPROP");

                entity.Property(e => e.Html)
                    .HasMaxLength(100)
                    .IsUnicode(false)
                    .HasColumnName("HTML");

                entity.Property(e => e.Nazvprop)
                    .HasMaxLength(300)
                    .IsUnicode(false)
                    .HasColumnName("NAZVPROP");

                entity.Property(e => e.Updatestatus)
                    .HasColumnType("numeric(1, 0)")
                    .HasColumnName("UPDATESTATUS");
            });

            modelBuilder.Entity<Property1>(entity =>
            {
                entity.HasKey(e => e.NPropertyId);

                entity.ToTable("PROPERTIES", "DIAG");

                entity.Property(e => e.NPropertyId)
                    .HasColumnType("numeric(10, 0)")
                    .HasColumnName("N_PROPERTY_ID");

                entity.Property(e => e.SCompoundCols)
                    .HasMaxLength(255)
                    .IsUnicode(false)
                    .HasColumnName("S_COMPOUND_COLS");

                entity.Property(e => e.SName)
                    .HasMaxLength(255)
                    .IsUnicode(false)
                    .HasColumnName("S_NAME");

                entity.Property(e => e.SPropertyCols)
                    .HasMaxLength(255)
                    .IsUnicode(false)
                    .HasColumnName("S_PROPERTY_COLS");

                entity.Property(e => e.STablenames)
                    .HasMaxLength(255)
                    .IsUnicode(false)
                    .HasColumnName("S_TABLENAMES");
            });

            modelBuilder.Entity<Propertygate>(entity =>
            {
                entity.HasNoKey();

                entity.ToTable("PROPERTYGATES", "DIAG");

                entity.Property(e => e.NCompoundDimension)
                    .HasColumnType("numeric(38, 0)")
                    .HasColumnName("N_COMPOUND_DIMENSION");

                entity.Property(e => e.NPropertyId)
                    .HasColumnType("numeric(10, 0)")
                    .HasColumnName("N_PROPERTY_ID");

                entity.Property(e => e.SRedirect2page)
                    .HasMaxLength(255)
                    .IsUnicode(false)
                    .HasColumnName("S_REDIRECT2PAGE");
            });

            modelBuilder.Entity<Section>(entity =>
            {
                entity.HasKey(e => e.SSectionId);

                entity.ToTable("SECTIONS", "DIAG");

                entity.Property(e => e.SSectionId)
                    .HasMaxLength(40)
                    .IsUnicode(false)
                    .HasColumnName("S_SECTION_ID");

                entity.Property(e => e.SSectionName)
                    .HasMaxLength(255)
                    .IsUnicode(false)
                    .HasColumnName("S_SECTION_NAME");
            });

            modelBuilder.Entity<Sys2analit>(entity =>
            {
                entity.HasNoKey();

                entity.ToTable("SYS2ANALIT", "DIAG");

                entity.Property(e => e.LHtml)
                    .HasColumnType("text")
                    .HasColumnName("L_HTML");

                entity.Property(e => e.SEl)
                    .HasMaxLength(30)
                    .IsUnicode(false)
                    .HasColumnName("S_EL");

                entity.Property(e => e.SEl1)
                    .HasMaxLength(4)
                    .IsUnicode(false)
                    .HasColumnName("S_EL1");

                entity.Property(e => e.SEl2)
                    .HasMaxLength(4)
                    .IsUnicode(false)
                    .HasColumnName("S_EL2");
            });

            modelBuilder.Entity<Sys2lit>(entity =>
            {
                entity.HasKey(e => new { e.SEl1, e.SEl2 });

                entity.ToTable("SYS2LIT", "DIAG");

                entity.Property(e => e.SEl1)
                    .HasMaxLength(10)
                    .IsUnicode(false)
                    .HasColumnName("S_EL1");

                entity.Property(e => e.SEl2)
                    .HasMaxLength(10)
                    .IsUnicode(false)
                    .HasColumnName("S_EL2");

                entity.Property(e => e.LNoms)
                    .HasColumnType("text")
                    .HasColumnName("L_NOMS");

                entity.Property(e => e.SEl)
                    .HasMaxLength(20)
                    .IsUnicode(false)
                    .HasColumnName("S_EL");

                entity.Property(e => e.SExpert)
                    .HasMaxLength(500)
                    .IsUnicode(false)
                    .HasColumnName("S_EXPERT");

                entity.Property(e => e.SRecenz)
                    .HasMaxLength(500)
                    .IsUnicode(false)
                    .HasColumnName("S_RECENZ");

                entity.Property(e => e.SUrov)
                    .HasMaxLength(1500)
                    .IsUnicode(false)
                    .HasColumnName("S_UROV");
            });

            modelBuilder.Entity<Sys3analit>(entity =>
            {
                entity.HasKey(e => e.SEl);

                entity.ToTable("SYS3ANALIT", "DIAG");

                entity.Property(e => e.SEl)
                    .HasMaxLength(30)
                    .IsUnicode(false)
                    .HasColumnName("S_EL");

                entity.Property(e => e.LHtml)
                    .HasColumnType("text")
                    .HasColumnName("L_HTML");

                entity.Property(e => e.SEl1)
                    .HasMaxLength(4)
                    .IsUnicode(false)
                    .HasColumnName("S_EL1");

                entity.Property(e => e.SEl2)
                    .HasMaxLength(4)
                    .IsUnicode(false)
                    .HasColumnName("S_EL2");

                entity.Property(e => e.SEl3)
                    .HasMaxLength(4)
                    .IsUnicode(false)
                    .HasColumnName("S_EL3");
            });

            modelBuilder.Entity<Sys3lit>(entity =>
            {
                entity.HasKey(e => new { e.SEl1, e.SEl2, e.SEl3 });

                entity.ToTable("SYS3LIT", "DIAG");

                entity.Property(e => e.SEl1)
                    .HasMaxLength(10)
                    .IsUnicode(false)
                    .HasColumnName("S_EL1");

                entity.Property(e => e.SEl2)
                    .HasMaxLength(10)
                    .IsUnicode(false)
                    .HasColumnName("S_EL2");

                entity.Property(e => e.SEl3)
                    .HasMaxLength(10)
                    .IsUnicode(false)
                    .HasColumnName("S_EL3");

                entity.Property(e => e.LNoms)
                    .HasColumnType("text")
                    .HasColumnName("L_NOMS");

                entity.Property(e => e.SEl)
                    .HasMaxLength(20)
                    .IsUnicode(false)
                    .HasColumnName("S_EL");

                entity.Property(e => e.SRecenz)
                    .HasMaxLength(500)
                    .IsUnicode(false)
                    .HasColumnName("S_RECENZ");

                entity.Property(e => e.SUrov)
                    .HasMaxLength(1500)
                    .IsUnicode(false)
                    .HasColumnName("S_UROV");
            });

            modelBuilder.Entity<Term>(entity =>
            {
                entity.HasKey(e => e.SEl);

                entity.ToTable("TERM", "DIAG");

                entity.Property(e => e.SEl)
                    .HasMaxLength(30)
                    .IsUnicode(false)
                    .HasColumnName("S_EL");

                entity.Property(e => e.LHtml)
                    .HasColumnType("text")
                    .HasColumnName("L_HTML");

                entity.Property(e => e.NNum)
                    .HasColumnType("numeric(38, 0)")
                    .HasColumnName("N_NUM");
            });

            modelBuilder.Entity<TripleExp>(entity =>
            {
                entity.HasKey(e => new { e.SEl1, e.SEl2, e.SEl3 });

                entity.ToTable("TRIPLE_EXP", "DIAG");

                entity.Property(e => e.SEl1)
                    .HasMaxLength(10)
                    .IsUnicode(false)
                    .HasColumnName("S_EL1");

                entity.Property(e => e.SEl2)
                    .HasMaxLength(10)
                    .IsUnicode(false)
                    .HasColumnName("S_EL2");

                entity.Property(e => e.SEl3)
                    .HasMaxLength(10)
                    .IsUnicode(false)
                    .HasColumnName("S_EL3");

                entity.Property(e => e.NSys)
                    .HasColumnType("numeric(38, 0)")
                    .HasColumnName("N_SYS");

                entity.Property(e => e.SCompoundName)
                    .HasMaxLength(255)
                    .IsUnicode(false)
                    .HasColumnName("S_COMPOUND_NAME");

                entity.Property(e => e.SEl1Sys1)
                    .HasMaxLength(20)
                    .IsUnicode(false)
                    .HasColumnName("S_EL1_SYS1");

                entity.Property(e => e.SEl1Sys2)
                    .HasMaxLength(20)
                    .IsUnicode(false)
                    .HasColumnName("S_EL1_SYS2");

                entity.Property(e => e.SEl1Sys3)
                    .HasMaxLength(20)
                    .IsUnicode(false)
                    .HasColumnName("S_EL1_SYS3");

                entity.Property(e => e.SEl2Sys1)
                    .HasMaxLength(20)
                    .IsUnicode(false)
                    .HasColumnName("S_EL2_SYS1");

                entity.Property(e => e.SEl2Sys2)
                    .HasMaxLength(20)
                    .IsUnicode(false)
                    .HasColumnName("S_EL2_SYS2");

                entity.Property(e => e.SEl2Sys3)
                    .HasMaxLength(20)
                    .IsUnicode(false)
                    .HasColumnName("S_EL2_SYS3");

                entity.Property(e => e.SExpert)
                    .HasMaxLength(1500)
                    .IsUnicode(false)
                    .HasColumnName("S_EXPERT");

                entity.Property(e => e.STerm)
                    .HasMaxLength(1500)
                    .IsUnicode(false)
                    .HasColumnName("S_TERM");
            });

            modelBuilder.Entity<TripleExpIsoterm>(entity =>
            {
                entity.HasKey(e => e.NCount);

                entity.ToTable("TRIPLE_EXP_ISOTERM", "DIAG");

                entity.Property(e => e.NCount)
                    .HasColumnType("numeric(38, 0)")
                    .HasColumnName("N_COUNT");

                entity.Property(e => e.NNom)
                    .HasColumnType("numeric(38, 0)")
                    .HasColumnName("N_NOM");

                entity.Property(e => e.NNumb).HasColumnName("N_NUMB");

                entity.Property(e => e.NPogr1).HasColumnName("N_POGR1");

                entity.Property(e => e.NPogr2).HasColumnName("N_POGR2");

                entity.Property(e => e.NTemperatura).HasColumnName("N_TEMPERATURA");

                entity.Property(e => e.NX).HasColumnName("N_X");

                entity.Property(e => e.NY).HasColumnName("N_Y");

                entity.Property(e => e.SCompoundName)
                    .HasMaxLength(255)
                    .IsUnicode(false)
                    .HasColumnName("S_COMPOUND_NAME");

                entity.Property(e => e.SEl1)
                    .HasMaxLength(4)
                    .IsUnicode(false)
                    .HasColumnName("S_EL1");

                entity.Property(e => e.SEl2)
                    .HasMaxLength(4)
                    .IsUnicode(false)
                    .HasColumnName("S_EL2");

                entity.Property(e => e.SEl3)
                    .HasMaxLength(4)
                    .IsUnicode(false)
                    .HasColumnName("S_EL3");

                entity.HasOne(d => d.NNomNavigation)
                    .WithMany(p => p.TripleExpIsoterms)
                    .HasForeignKey(d => d.NNom)
                    .HasConstraintName("FK_TRIPLE_EXP_ISOTERM_LITERAT");
            });

            modelBuilder.Entity<TripleExpKvaz>(entity =>
            {
                entity.HasKey(e => e.NCount);

                entity.ToTable("TRIPLE_EXP_KVAZ", "DIAG");

                entity.Property(e => e.NCount)
                    .HasColumnType("numeric(38, 0)")
                    .HasColumnName("N_COUNT");

                entity.Property(e => e.NNom)
                    .HasColumnType("numeric(38, 0)")
                    .HasColumnName("N_NOM");

                entity.Property(e => e.NNumb).HasColumnName("N_NUMB");

                entity.Property(e => e.NPogr1).HasColumnName("N_POGR1");

                entity.Property(e => e.NPogr2).HasColumnName("N_POGR2");

                entity.Property(e => e.NPogr3).HasColumnName("N_POGR3");

                entity.Property(e => e.NPress).HasColumnName("N_PRESS");

                entity.Property(e => e.NTemperatura).HasColumnName("N_TEMPERATURA");

                entity.Property(e => e.NX).HasColumnName("N_X");

                entity.Property(e => e.SCompoundName)
                    .HasMaxLength(256)
                    .IsUnicode(false)
                    .HasColumnName("S_COMPOUND_NAME");

                entity.Property(e => e.SEl1)
                    .HasMaxLength(4)
                    .IsUnicode(false)
                    .HasColumnName("S_EL1");

                entity.Property(e => e.SEl2)
                    .HasMaxLength(4)
                    .IsUnicode(false)
                    .HasColumnName("S_EL2");

                entity.Property(e => e.SEl3)
                    .HasMaxLength(4)
                    .IsUnicode(false)
                    .HasColumnName("S_EL3");

                entity.Property(e => e.SLine)
                    .HasMaxLength(64)
                    .IsUnicode(false)
                    .HasColumnName("S_LINE");

                entity.Property(e => e.SRazres)
                    .HasMaxLength(300)
                    .IsUnicode(false)
                    .HasColumnName("S_RAZRES");

                entity.HasOne(d => d.NNomNavigation)
                    .WithMany(p => p.TripleExpKvazs)
                    .HasForeignKey(d => d.NNom)
                    .HasConstraintName("FK_TRIPLE_EXP_KVAZ_LITERAT");
            });

            modelBuilder.Entity<TripleExpPoverh>(entity =>
            {
                entity.HasNoKey();

                entity.ToTable("TRIPLE_EXP_POVERH", "DIAG");

                entity.Property(e => e.NCount)
                    .HasColumnType("numeric(20, 0)")
                    .HasColumnName("N_COUNT");

                entity.Property(e => e.NNom)
                    .HasColumnType("numeric(38, 0)")
                    .HasColumnName("N_NOM");

                entity.Property(e => e.NNumb)
                    .HasColumnType("numeric(20, 0)")
                    .HasColumnName("N_NUMB");

                entity.Property(e => e.NPogr1).HasColumnName("N_POGR1");

                entity.Property(e => e.NPogr2).HasColumnName("N_POGR2");

                entity.Property(e => e.NX).HasColumnName("N_X");

                entity.Property(e => e.NY).HasColumnName("N_Y");

                entity.Property(e => e.SCompoundName)
                    .HasMaxLength(255)
                    .IsUnicode(false)
                    .HasColumnName("S_COMPOUND_NAME");

                entity.Property(e => e.SEl1)
                    .HasMaxLength(4)
                    .IsUnicode(false)
                    .HasColumnName("S_EL1");

                entity.Property(e => e.SEl2)
                    .HasMaxLength(4)
                    .IsUnicode(false)
                    .HasColumnName("S_EL2");

                entity.Property(e => e.SEl3)
                    .HasMaxLength(4)
                    .IsUnicode(false)
                    .HasColumnName("S_EL3");

                entity.Property(e => e.SLine)
                    .HasMaxLength(50)
                    .IsUnicode(false)
                    .HasColumnName("S_LINE");
            });

            modelBuilder.Entity<TripleGraf>(entity =>
            {
                entity.HasKey(e => e.NCount);

                entity.ToTable("TRIPLE_GRAF", "DIAG");

                entity.Property(e => e.NCount)
                    .HasColumnType("numeric(38, 0)")
                    .HasColumnName("N_COUNT");

                entity.Property(e => e.LImg)
                    .HasColumnType("image")
                    .HasColumnName("L_IMG");

                entity.Property(e => e.SCompoundName)
                    .HasMaxLength(255)
                    .IsUnicode(false)
                    .HasColumnName("S_COMPOUND_NAME");

                entity.Property(e => e.SEl1)
                    .HasMaxLength(10)
                    .IsUnicode(false)
                    .HasColumnName("S_EL1");

                entity.Property(e => e.SEl2)
                    .HasMaxLength(10)
                    .IsUnicode(false)
                    .HasColumnName("S_EL2");

                entity.Property(e => e.SEl3)
                    .HasMaxLength(10)
                    .IsUnicode(false)
                    .HasColumnName("S_EL3");

                entity.Property(e => e.STitle)
                    .HasMaxLength(500)
                    .IsUnicode(false)
                    .HasColumnName("S_TITLE");
            });

            modelBuilder.Entity<TripleKrist>(entity =>
            {
                entity.HasKey(e => e.NCount);

                entity.ToTable("TRIPLE_KRIST", "DIAG");

                entity.Property(e => e.NCount)
                    .HasColumnType("numeric(38, 0)")
                    .HasColumnName("N_COUNT");

                entity.Property(e => e.NA).HasColumnName("N_A");

                entity.Property(e => e.NAlpha).HasColumnName("N_ALPHA");

                entity.Property(e => e.NB).HasColumnName("N_B");

                entity.Property(e => e.NBeta).HasColumnName("N_BETA");

                entity.Property(e => e.NC).HasColumnName("N_C");

                entity.Property(e => e.NGamma).HasColumnName("N_GAMMA");

                entity.Property(e => e.NNom)
                    .HasColumnType("numeric(38, 0)")
                    .HasColumnName("N_NOM");

                entity.Property(e => e.NPogr1).HasColumnName("N_POGR1");

                entity.Property(e => e.NPogr2).HasColumnName("N_POGR2");

                entity.Property(e => e.NPogr3).HasColumnName("N_POGR3");

                entity.Property(e => e.NPogr4).HasColumnName("N_POGR4");

                entity.Property(e => e.NPogr5).HasColumnName("N_POGR5");

                entity.Property(e => e.NPogr6).HasColumnName("N_POGR6");

                entity.Property(e => e.SCompoundName)
                    .HasMaxLength(256)
                    .IsUnicode(false)
                    .HasColumnName("S_COMPOUND_NAME");

                entity.Property(e => e.SEl1)
                    .HasMaxLength(10)
                    .IsUnicode(false)
                    .HasColumnName("S_EL1");

                entity.Property(e => e.SEl2)
                    .HasMaxLength(10)
                    .IsUnicode(false)
                    .HasColumnName("S_EL2");

                entity.Property(e => e.SEl3)
                    .HasMaxLength(10)
                    .IsUnicode(false)
                    .HasColumnName("S_EL3");

                entity.Property(e => e.SFaza)
                    .HasMaxLength(64)
                    .IsUnicode(false)
                    .HasColumnName("S_FAZA");

                entity.Property(e => e.SPirson)
                    .HasMaxLength(128)
                    .IsUnicode(false)
                    .HasColumnName("S_PIRSON");

                entity.Property(e => e.SSpgr)
                    .HasMaxLength(128)
                    .IsUnicode(false)
                    .HasColumnName("S_SPGR");

                entity.Property(e => e.STitle)
                    .HasMaxLength(1024)
                    .IsUnicode(false)
                    .HasColumnName("S_TITLE");

                entity.Property(e => e.STypestr)
                    .HasMaxLength(128)
                    .IsUnicode(false)
                    .HasColumnName("S_TYPESTR");

                entity.HasOne(d => d.NNomNavigation)
                    .WithMany(p => p.TripleKrists)
                    .HasForeignKey(d => d.NNom)
                    .HasConstraintName("FK_TRIPLE_KRIST_LITERAT");
            });

            modelBuilder.Entity<TripleOsob1>(entity =>
            {
                entity.HasKey(e => e.NCount);

                entity.ToTable("TRIPLE_OSOB1", "DIAG");

                entity.Property(e => e.NCount)
                    .HasColumnType("numeric(38, 0)")
                    .HasColumnName("N_COUNT");

                entity.Property(e => e.NNom)
                    .HasColumnType("numeric(38, 0)")
                    .HasColumnName("N_NOM");

                entity.Property(e => e.NPogr1).HasColumnName("N_POGR1");

                entity.Property(e => e.NPogr2).HasColumnName("N_POGR2");

                entity.Property(e => e.NPress).HasColumnName("N_PRESS");

                entity.Property(e => e.NTemperatura).HasColumnName("N_TEMPERATURA");

                entity.Property(e => e.SCompoundName)
                    .HasMaxLength(256)
                    .IsUnicode(false)
                    .HasColumnName("S_COMPOUND_NAME");

                entity.Property(e => e.SEl1)
                    .HasMaxLength(10)
                    .IsUnicode(false)
                    .HasColumnName("S_EL1");

                entity.Property(e => e.SEl2)
                    .HasMaxLength(10)
                    .IsUnicode(false)
                    .HasColumnName("S_EL2");

                entity.Property(e => e.SEl3)
                    .HasMaxLength(10)
                    .IsUnicode(false)
                    .HasColumnName("S_EL3");

                entity.Property(e => e.SReak)
                    .HasMaxLength(300)
                    .IsUnicode(false)
                    .HasColumnName("S_REAK");

                entity.Property(e => e.STitle)
                    .HasMaxLength(1536)
                    .IsUnicode(false)
                    .HasColumnName("S_TITLE");

                entity.Property(e => e.SType)
                    .HasMaxLength(50)
                    .IsUnicode(false)
                    .HasColumnName("S_TYPE");

                entity.HasOne(d => d.NNomNavigation)
                    .WithMany(p => p.TripleOsob1s)
                    .HasForeignKey(d => d.NNom)
                    .HasConstraintName("FK_TRIPLE_OSOB1_LITERAT");
            });

            modelBuilder.Entity<TripleOsob2>(entity =>
            {
                entity.HasKey(e => e.NCount);

                entity.ToTable("TRIPLE_OSOB2", "DIAG");

                entity.Property(e => e.NCount)
                    .HasColumnType("numeric(38, 0)")
                    .HasColumnName("N_COUNT");

                entity.Property(e => e.NNom)
                    .HasColumnType("numeric(38, 0)")
                    .HasColumnName("N_NOM");

                entity.Property(e => e.NPogr1).HasColumnName("N_POGR1");

                entity.Property(e => e.NPogr2).HasColumnName("N_POGR2");

                entity.Property(e => e.NX).HasColumnName("N_X");

                entity.Property(e => e.NY).HasColumnName("N_Y");

                entity.Property(e => e.SEl1)
                    .HasMaxLength(10)
                    .IsUnicode(false)
                    .HasColumnName("S_EL1");

                entity.Property(e => e.SEl2)
                    .HasMaxLength(10)
                    .IsUnicode(false)
                    .HasColumnName("S_EL2");

                entity.Property(e => e.SEl3)
                    .HasMaxLength(10)
                    .IsUnicode(false)
                    .HasColumnName("S_EL3");

                entity.Property(e => e.SFaza)
                    .HasMaxLength(64)
                    .IsUnicode(false)
                    .HasColumnName("S_FAZA");

                entity.Property(e => e.SReak)
                    .HasMaxLength(300)
                    .IsUnicode(false)
                    .HasColumnName("S_REAK");

                entity.HasOne(d => d.NNomNavigation)
                    .WithMany(p => p.TripleOsob2s)
                    .HasForeignKey(d => d.NNom)
                    .HasConstraintName("FK_TRIPLE_OSOB2_LITERAT");
            });

            modelBuilder.Entity<TripleSoglIsoterm>(entity =>
            {
                entity.HasKey(e => e.NCount);

                entity.ToTable("TRIPLE_SOGL_ISOTERM", "DIAG");

                entity.Property(e => e.NCount)
                    .HasColumnType("numeric(38, 0)")
                    .HasColumnName("N_COUNT");

                entity.Property(e => e.NNumb).HasColumnName("N_NUMB");

                entity.Property(e => e.NPogr1).HasColumnName("N_POGR1");

                entity.Property(e => e.NPogr2).HasColumnName("N_POGR2");

                entity.Property(e => e.NTemperatura).HasColumnName("N_TEMPERATURA");

                entity.Property(e => e.NX).HasColumnName("N_X");

                entity.Property(e => e.NY).HasColumnName("N_Y");

                entity.Property(e => e.SCompoundName)
                    .HasMaxLength(256)
                    .IsUnicode(false)
                    .HasColumnName("S_COMPOUND_NAME");

                entity.Property(e => e.SEl1)
                    .HasMaxLength(4)
                    .IsUnicode(false)
                    .HasColumnName("S_EL1");

                entity.Property(e => e.SEl2)
                    .HasMaxLength(4)
                    .IsUnicode(false)
                    .HasColumnName("S_EL2");

                entity.Property(e => e.SEl3)
                    .HasMaxLength(4)
                    .IsUnicode(false)
                    .HasColumnName("S_EL3");
            });

            modelBuilder.Entity<TripleSoglKvaz>(entity =>
            {
                entity.HasKey(e => e.NCount);

                entity.ToTable("TRIPLE_SOGL_KVAZ", "DIAG");

                entity.Property(e => e.NCount)
                    .HasColumnType("numeric(38, 0)")
                    .HasColumnName("N_COUNT");

                entity.Property(e => e.NNumb).HasColumnName("N_NUMB");

                entity.Property(e => e.NPogr1).HasColumnName("N_POGR1");

                entity.Property(e => e.NPogr2).HasColumnName("N_POGR2");

                entity.Property(e => e.NPress).HasColumnName("N_PRESS");

                entity.Property(e => e.NTemperatura).HasColumnName("N_TEMPERATURA");

                entity.Property(e => e.NX).HasColumnName("N_X");

                entity.Property(e => e.SCompoundName)
                    .HasMaxLength(256)
                    .IsUnicode(false)
                    .HasColumnName("S_COMPOUND_NAME");

                entity.Property(e => e.SEl1)
                    .HasMaxLength(4)
                    .IsUnicode(false)
                    .HasColumnName("S_EL1");

                entity.Property(e => e.SEl2)
                    .HasMaxLength(4)
                    .IsUnicode(false)
                    .HasColumnName("S_EL2");

                entity.Property(e => e.SEl3)
                    .HasMaxLength(4)
                    .IsUnicode(false)
                    .HasColumnName("S_EL3");

                entity.Property(e => e.SLine)
                    .HasMaxLength(64)
                    .IsUnicode(false)
                    .HasColumnName("S_LINE");

                entity.Property(e => e.SRazres)
                    .HasMaxLength(300)
                    .IsUnicode(false)
                    .HasColumnName("S_RAZRES");
            });

            modelBuilder.Entity<TripleSoglPoverh>(entity =>
            {
                entity.HasKey(e => e.NCount);

                entity.ToTable("TRIPLE_SOGL_POVERH", "DIAG");

                entity.Property(e => e.NCount)
                    .HasColumnType("numeric(38, 0)")
                    .HasColumnName("N_COUNT");

                entity.Property(e => e.NNumb).HasColumnName("N_NUMB");

                entity.Property(e => e.NPogr1).HasColumnName("N_POGR1");

                entity.Property(e => e.NPogr2).HasColumnName("N_POGR2");

                entity.Property(e => e.NX).HasColumnName("N_X");

                entity.Property(e => e.NY).HasColumnName("N_Y");

                entity.Property(e => e.SCompoundName)
                    .HasMaxLength(256)
                    .IsUnicode(false)
                    .HasColumnName("S_COMPOUND_NAME");

                entity.Property(e => e.SEl1)
                    .HasMaxLength(4)
                    .IsUnicode(false)
                    .HasColumnName("S_EL1");

                entity.Property(e => e.SEl2)
                    .HasMaxLength(4)
                    .IsUnicode(false)
                    .HasColumnName("S_EL2");

                entity.Property(e => e.SEl3)
                    .HasMaxLength(4)
                    .IsUnicode(false)
                    .HasColumnName("S_EL3");

                entity.Property(e => e.SLine)
                    .HasMaxLength(64)
                    .IsUnicode(false)
                    .HasColumnName("S_LINE");
            });

            modelBuilder.Entity<TripleUrov>(entity =>
            {
                entity.HasKey(e => e.NUrov);

                entity.ToTable("TRIPLE_UROV", "DIAG");

                entity.Property(e => e.NUrov)
                    .HasColumnType("numeric(38, 0)")
                    .HasColumnName("N_UROV");

                entity.Property(e => e.SUrov)
                    .HasMaxLength(2000)
                    .IsUnicode(false)
                    .HasColumnName("S_UROV");
            });

            modelBuilder.Entity<User>(entity =>
            {
                entity.HasKey(e => e.NUserId);

                entity.ToTable("USERS", "DIAG");

                entity.Property(e => e.NUserId)
                    .HasColumnType("numeric(38, 0)")
                    .HasColumnName("N_USER_ID");

                entity.Property(e => e.CRole)
                    .HasMaxLength(4)
                    .IsUnicode(false)
                    .HasColumnName("C_ROLE")
                    .IsFixedLength();

                entity.Property(e => e.DExpiredate)
                    .HasColumnType("datetime")
                    .HasColumnName("D_EXPIREDATE");

                entity.Property(e => e.DExprise)
                    .HasColumnType("datetime")
                    .HasColumnName("D_EXPRISE");

                entity.Property(e => e.DLastlogin)
                    .HasColumnType("datetime")
                    .HasColumnName("D_LASTLOGIN");

                entity.Property(e => e.NEndhour)
                    .HasColumnType("numeric(38, 0)")
                    .HasColumnName("N_ENDHOUR");

                entity.Property(e => e.NStarthour)
                    .HasColumnType("numeric(38, 0)")
                    .HasColumnName("N_STARTHOUR");

                entity.Property(e => e.SAddress)
                    .HasMaxLength(300)
                    .IsUnicode(false)
                    .HasColumnName("S_ADDRESS");

                entity.Property(e => e.SAllowedIp)
                    .HasMaxLength(15)
                    .IsUnicode(false)
                    .HasColumnName("S_ALLOWED_IP");

                entity.Property(e => e.SCountry)
                    .HasMaxLength(50)
                    .IsUnicode(false)
                    .HasColumnName("S_COUNTRY");

                entity.Property(e => e.SFullname)
                    .HasMaxLength(100)
                    .IsUnicode(false)
                    .HasColumnName("S_FULLNAME");

                entity.Property(e => e.SMail)
                    .HasMaxLength(150)
                    .IsUnicode(false)
                    .HasColumnName("S_MAIL");

                entity.Property(e => e.SOrg)
                    .HasMaxLength(200)
                    .IsUnicode(false)
                    .HasColumnName("S_ORG");

                entity.Property(e => e.SPassword)
                    .HasMaxLength(10)
                    .IsUnicode(false)
                    .HasColumnName("S_PASSWORD");

                entity.Property(e => e.STelfax)
                    .HasMaxLength(200)
                    .IsUnicode(false)
                    .HasColumnName("S_TELFAX");

                entity.Property(e => e.SUsername)
                    .HasMaxLength(10)
                    .IsUnicode(false)
                    .HasColumnName("S_USERNAME");
            });

            modelBuilder.Entity<UserCompound>(entity =>
            {
                entity.HasNoKey();

                entity.ToTable("USER_COMPOUNDS", "DIAG");

                entity.Property(e => e.SCompoundName)
                    .HasMaxLength(255)
                    .IsUnicode(false)
                    .HasColumnName("S_COMPOUND_NAME");

                entity.Property(e => e.SUsername)
                    .HasMaxLength(10)
                    .IsUnicode(false)
                    .HasColumnName("S_USERNAME");
            });

            modelBuilder.Entity<UserSection>(entity =>
            {
                entity.HasNoKey();

                entity.ToTable("USER_SECTIONS", "DIAG");

                entity.Property(e => e.SSectionId)
                    .HasMaxLength(40)
                    .IsUnicode(false)
                    .HasColumnName("S_SECTION_ID");

                entity.Property(e => e.SUsername)
                    .HasMaxLength(10)
                    .IsUnicode(false)
                    .HasColumnName("S_USERNAME");
            });

            modelBuilder.Entity<Usersinfo>(entity =>
            {
                entity.HasKey(e => e.Userid);

                entity.ToTable("_USERSINFO", "DIAG");

                entity.Property(e => e.Userid)
                    .ValueGeneratedNever()
                    .HasColumnName("USERID");

                entity.Property(e => e.Accessmode)
                    .HasColumnType("numeric(10, 0)")
                    .HasColumnName("ACCESSMODE");

                entity.Property(e => e.Comments)
                    .HasMaxLength(256)
                    .IsUnicode(false)
                    .HasColumnName("COMMENTS");

                entity.Property(e => e.Login)
                    .HasMaxLength(16)
                    .IsUnicode(false)
                    .HasColumnName("LOGIN");

                entity.Property(e => e.Password)
                    .HasMaxLength(32)
                    .IsUnicode(false)
                    .HasColumnName("PASSWORD");

                entity.Property(e => e.Updatestatus)
                    .HasColumnType("numeric(1, 0)")
                    .HasColumnName("UPDATESTATUS");
            });

            modelBuilder.Entity<Models.Version>(entity =>
            {
                entity.HasNoKey();

                entity.ToTable("VERSION", "DIAG");

                entity.Property(e => e.SVersion)
                    .HasMaxLength(100)
                    .IsUnicode(false)
                    .HasColumnName("S_VERSION");
            });

            modelBuilder.Entity<Webhit>(entity =>
            {
                entity.HasKey(e => e.SUsername);

                entity.ToTable("WEBHITS", "DIAG");

                entity.Property(e => e.SUsername)
                    .HasMaxLength(10)
                    .IsUnicode(false)
                    .HasColumnName("S_USERNAME");

                entity.Property(e => e.DLastdate)
                    .HasColumnType("datetime")
                    .HasColumnName("D_LASTDATE");

                entity.Property(e => e.NHits)
                    .HasColumnType("numeric(38, 0)")
                    .HasColumnName("N_HITS");
            });

            OnModelCreatingPartial(modelBuilder);
        }

        partial void OnModelCreatingPartial(ModelBuilder modelBuilder);
    }
}
